"""Validate pilot outputs with vLLM's comparison helper and summarize latency."""
import argparse
import json
import statistics
import sys
from pathlib import Path


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('root',type=Path)
    ap.add_argument('--repo',type=Path,default=Path('/root/shared-nvme/vllm'))
    args=ap.parse_args()
    sys.path.insert(0,str(args.repo))
    from vllm.logprobs import Logprob
    from tests.models.utils import check_logprobs_close
    records=[json.loads((args.root/arm/'correctness.json').read_text()) for arm in ['stock','pruned']]
    assert records[0]['prompts']==records[1]['prompts']

    def convert(record, field):
        result=[]
        for r in record[field]:
            logprobs=[{int(k):Logprob(**v) for k,v in row.items()} for row in r['logprobs']]
            item=(r['token_ids'],r['text'],logprobs)
            if r['prompt_logprobs'] is not None:
                item+=([None if row is None else {int(k):Logprob(**v) for k,v in row.items()}
                        for row in r['prompt_logprobs']],)
            result.append(item)
        return result

    for field in ['outputs','prompt_logprobs_fallback']:
        check_logprobs_close(outputs_0_lst=convert(records[0],field),
                             outputs_1_lst=convert(records[1],field),
                             name_0='stock',name_1='pruned')
    before=records[1]['before_fallback'][0]['pruning']
    after=records[1]['worker_stats'][0]['pruning']
    assert before['batches']>0
    assert before==after, 'Prompt-logprob requests unexpectedly used pruning'
    exact=sum(a['token_ids']==b['token_ids'] for a,b in zip(records[0]['outputs'],records[1]['outputs']))
    rows=[]
    for n in [128,512,2048,4096]:
        for b in [1,4]:
            pair=[json.loads((args.root/arm/f'input{n}-batch{b}.json').read_text()) for arm in ['stock','pruned']]
            for r in pair:
                assert r['worker_stats'][0]['breakable_entries']>0
            a,z=[r['median_elapsed_ms'] for r in pair]
            rows.append({'input_tokens':n,'batch':b,'stock_median_ms':a,'pruned_median_ms':z,
                         'latency_change_pct':(z/a-1)*100,
                         'stock_mean_ttft_ms':pair[0]['mean_ttft_ms'],
                         'pruned_mean_ttft_ms':pair[1]['mean_ttft_ms'],
                         'stock_samples_ms':[s['elapsed_ms'] for s in pair[0]['samples']],
                         'pruned_samples_ms':[s['elapsed_ms'] for s in pair[1]['samples']]})
    summary={'correctness':'passed vLLM check_logprobs_close with default tolerances',
             'identical_token_sequences':exact,'total_sequences':len(records[0]['outputs']),
             'prompt_logprobs_fallback_verified':True,'rows':rows}
    (args.root/'comparison.json').write_text(json.dumps(summary,indent=2))
    lines=['# Llama-3.2-1B-Instruct 最后一层 FFN 裁剪小规模验证','',
           '单张 RTX 4090，BF16、FlashAttention 2；双方开启 breakable Prefill CUDA Graph，关闭前缀缓存。',
           '性能为真实权重下离线 `LLM.generate` 的端到端耗时，输出 1 token；不含模型加载、Graph 捕获和预热。',
           '每格记录 7 次测量，表中为耗时中位数；变化为负表示改善。','',
           f'正确性：{exact}/{len(records[0]["outputs"])} 条生成序列 token 完全相同；vLLM 默认 `check_logprobs_close` 对照通过。',
           '请求 prompt logprobs 时确认未启用裁剪，对照检查通过。','',
           '| 输入 tokens | batch | 原版 ms | 裁剪 ms | 耗时变化 |',
           '| ---: | ---: | ---: | ---: | ---: |']
    lines += [f'| {r["input_tokens"]} | {r["batch"]} | {r["stock_median_ms"]:.3f} | {r["pruned_median_ms"]:.3f} | {r["latency_change_pct"]:+.2f}% |' for r in rows]
    lines += ['', '逐次测量与逐请求输出保存在 `stock/` 和 `pruned/`。本轮是小规模探索，尚未做多轮交替复测。']
    (args.root/'结果分析.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
