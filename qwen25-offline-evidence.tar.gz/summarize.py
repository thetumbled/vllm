import json,statistics
from pathlib import Path
root=Path('/root/shared-nvme/vllm-last-layer-ffn/qwen25-pilot-v1')
summaries=[json.loads((root/f'round{i}'/'comparison.json').read_text()) for i in (1,2)]
rows=[]
for first,second in zip(summaries[0]['rows'],summaries[1]['rows']):
 assert (first['input_tokens'],first['batch'])==(second['input_tokens'],second['batch'])
 stock=statistics.mean([first['stock_median_ms'],second['stock_median_ms']]);pruned=statistics.mean([first['pruned_median_ms'],second['pruned_median_ms']])
 rows.append(dict(input_tokens=first['input_tokens'],batch=first['batch'],stock_ms=stock,pruned_ms=pruned,change_pct=100*(pruned/stock-1),round1_pct=first['latency_change_pct'],round2_pct=second['latency_change_pct']))
(root/'combined.json').write_text(json.dumps({'rows':rows,'correctness':[{'identical':s['identical_token_sequences'],'total':s['total_sequences'],'status':s['correctness']} for s in summaries]},indent=2))
lines=['# Qwen2.5-7B-Instruct：vLLM FFN 裁剪小规模验证','',
'单张 RTX 4090，BF16，双方使用同一 Transformers 后端、FlashAttention 2 和 breakable Prefill CUDA Graph，关闭前缀缓存。',
'仅选择最后一层 FFN 的所需行，残差和归一化保持原形状；不更换模型后端。',
'运行顺序为原版→裁剪版→裁剪版→原版。每个配置每轮预热 2 次、测量 7 次，输出 1 token。',
'指标是离线 `LLM.generate` 的端到端耗时，不含加载、捕获和预热；不是纯 GPU kernel 时间。',
'表中耗时为两轮中位数的平均；负变化表示降低。','',
'| 输入 tokens | batch | 原版 ms | 裁剪 ms | 综合变化 | 第1轮变化 | 第2轮变化 |',
'| ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
lines += [f'| {r["input_tokens"]} | {r["batch"]} | {r["stock_ms"]:.3f} | {r["pruned_ms"]:.3f} | {r["change_pct"]:+.2f}% | {r["round1_pct"]:+.2f}% | {r["round2_pct"]:+.2f}% |' for r in rows]
lines += ['','## 正确性','']
for i,s in enumerate(summaries,1):lines.append(f'- 第{i}轮：{s["identical_token_sequences"]}/{s["total_sequences"]} 条生成 token 序列完全一致；vLLM 默认对照检查和 prompt logprobs 回退检查通过。')
lines += ['', '正式 Eager/Graph、缓存前缀与分块 Prefill 回归结果见 `regressions.xml` 和 `regressions.log`。', '本轮为小规模验证，完整逐次测量在 `round1/` 和 `round2/`。']
(root/'结果分析.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
