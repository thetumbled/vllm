import json,os,subprocess,time,traceback
from pathlib import Path
repo=Path('/root/shared-nvme/vllm');root=Path('/root/shared-nvme/vllm-last-layer-ffn/qwen25-pilot-v1');python=str(repo/'.venv/bin/python')
env=os.environ.copy();env['VLLM_WORKER_MULTIPROC_METHOD']='spawn'
(root/'model-redirect.json').write_text(json.dumps({'Qwen/Qwen3-4B':'/root/shared-nvme/models/Qwen3-4B','Qwen/Qwen2.5-7B-Instruct':'/root/shared-nvme/models/Qwen2.5-7B-Instruct'}))
env['VLLM_MODEL_REDIRECT_PATH']=str(root/'model-redirect.json')
def progress(state,**kw):
 p=root/'progress.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps({'state':state,'updated_at':time.time(),**kw},indent=2));tmp.replace(p)
def stage(name,cmd):
 if (root/(name+'.done')).exists():return
 progress('running',stage=name)
 with (root/(name+'.log')).open('a') as f:
  f.write(f'\nSTART {time.time()} {cmd}\n');f.flush()
  subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 (root/(name+'.done')).write_text(str(time.time()))
try:
 stage('regressions',[python,'-m','pytest','-v','-s','tests/v1/cudagraph/test_last_layer_ffn.py','-k','Qwen2.5 or (Qwen3 and graph)',f'--junitxml={root}/regressions.xml'])
 for repeat,arms in [(1,['stock','pruned']),(2,['pruned','stock'])]:
  for arm in arms:
   env['VLLM_ENABLE_LAST_LAYER_FFN_PRUNING']='1' if arm=='pruned' else '0'
   stage(f'round{repeat}-{arm}',[python,str(root/'pilot_qwen25.py'),'--arm',arm,'--out',str(root/f'round{repeat}'/arm)])
  stage(f'round{repeat}-analysis',[python,str(root/'analyze.py'),str(root/f'round{repeat}')])
 progress('complete',completed=4,total=4)
except Exception:
 progress('stopped',error=traceback.format_exc());raise
